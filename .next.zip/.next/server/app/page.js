(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 7999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 7244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2527);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7651)), "C:\\Users\\ProKa\\OneDrive\\Desktop\\Application\\Nextjs Applications\\nextcarrental\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 729)), "C:\\Users\\ProKa\\OneDrive\\Desktop\\Application\\Nextjs Applications\\nextcarrental\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ProKa\\OneDrive\\Desktop\\Application\\Nextjs Applications\\nextcarrental\\app\\page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 573:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1897));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5608));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4620));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2259))

/***/ }),

/***/ 9174:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1897));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5608));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4620));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2259))

/***/ }),

/***/ 4005:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9775, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_CarCard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./utils/index.ts
var utils = __webpack_require__(1806);
// EXTERNAL MODULE: ./components/CustomButton.tsx
var CustomButton = __webpack_require__(1897);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 22 modules
var dialog = __webpack_require__(3483);
;// CONCATENATED MODULE: ./components/CarDetails.tsx





const CarDetails = ({ isOpen, closeModal, car })=>/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
            appear: true,
            show: isOpen,
            as: react_.Fragment,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
                as: "div",
                className: "relative z-10",
                onClose: closeModal,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u.Child, {
                        as: react_.Fragment,
                        enter: "ease-out duration-300",
                        enterFrom: "opacity-0",
                        enterTo: "opacity-100",
                        leave: "ease-in duration-200",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "fixed inset-0 bg-black bg-opacity-25"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 overflow-y-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex min-h-full items-center justify-center p-4 text-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u.Child, {
                                as: react_.Fragment,
                                enter: "ease-out duration-300",
                                enterFrom: "opacity-0 scale-95",
                                enterTo: "opacity-100 scale-100",
                                leave: "ease-out duration-300",
                                leaveFrom: "opacity-100 scale-100",
                                leaveTo: "opacity-0 scale-95",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V.Panel, {
                                    className: "relative w-full max-w-lg max-h-[90vh] overflow-y-auto transform rounded-2xl bg-white p-6 text-left shadow-xl transition-all flex flex-col gap-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: "absolute top-2 right-2 z-10 w-fit p-2 bg-primary-blue-100 rounded-full",
                                            onClick: closeModal,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/close.svg",
                                                alt: "close",
                                                width: 20,
                                                height: 20,
                                                className: "object-contain"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex-1 flex flex-col gap-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "relative w-full h-40 bg-pattern bg-cover bg-center rounded-lg",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: (0,utils/* generateCarImageUrl */.tx)(car),
                                                        alt: "car model",
                                                        fill: true,
                                                        priority: true,
                                                        className: "object-contain"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "flex-1 relative w-full h-24 bg-primary-blue-100 rounded-lg",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: (0,utils/* generateCarImageUrl */.tx)(car, "29"),
                                                                alt: "car model",
                                                                fill: true,
                                                                priority: true,
                                                                className: "object-contain"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "flex-1 relative w-full h-24 bg-primary-blue-100 rounded-lg",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: (0,utils/* generateCarImageUrl */.tx)(car, "33"),
                                                                alt: "car model",
                                                                fill: true,
                                                                priority: true,
                                                                className: "object-contain"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "flex-1 relative w-full h-24 bg-primary-blue-100 rounded-lg",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: (0,utils/* generateCarImageUrl */.tx)(car, "13"),
                                                                alt: "car model",
                                                                fill: true,
                                                                priority: true,
                                                                className: "object-contain"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex-1 flex flex-col gap-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                                    className: "font-semibold text-xl capitalize",
                                                    children: [
                                                        car.make,
                                                        " ",
                                                        car.model
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "mt-3 flex flex-wrap gap-4",
                                                    children: Object.entries(car).map(([key, value])=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex justify-between gap-5 w-full text-right",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                    className: "text-grey capitalize",
                                                                    children: key.split("_").join(" ")
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: "text-black-100 font-semibold",
                                                                    children: value
                                                                })
                                                            ]
                                                        }, key))
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
/* harmony default export */ const components_CarDetails = (CarDetails);

;// CONCATENATED MODULE: ./components/CarCard.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const CarCard = ({ car })=>{
    const { city_mpg, year, make, model, transmission, drive } = car;
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    const carRent = (0,utils/* calculateCarRent */.Q_)(city_mpg, year);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "car-card group",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "car-card__content",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: "car-card__content-title",
                    children: [
                        make,
                        " ",
                        model
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "flex mt-6 text-[32px] leading-[38px] font-extrabold",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "self-start text-[14px] leading-[17px] font-semibold",
                        children: "$"
                    }),
                    carRent,
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "self-end text-[14px] leading-[17px] font-medium",
                        children: "/day"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full h-40 my-3 object-contain",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: (0,utils/* generateCarImageUrl */.tx)(car),
                    alt: "car model",
                    fill: true,
                    priority: true,
                    className: "object-contain"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex w-full mt-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex group-hover:invisible w-full justify-between text-grey",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-center items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/steering-wheel.svg",
                                        width: 20,
                                        height: 20,
                                        alt: "steering wheel"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-[14px] leading-[17px]",
                                        children: transmission === "a" ? "Automatic" : "Manual"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "car-card__icon",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/tire.svg",
                                        width: 20,
                                        height: 20,
                                        alt: "seat"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "car-card__icon-text",
                                        children: drive.toUpperCase()
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "car-card__icon",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/gas.svg",
                                        width: 20,
                                        height: 20,
                                        alt: "seat"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "car-card__icon-text",
                                        children: [
                                            city_mpg,
                                            " MPG"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "car-card__btn-container",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(CustomButton["default"], {
                            title: "View More",
                            containerStyles: "w-full py-[16px] rounded-full bg-primary-blue",
                            textStyles: "text-white text-[14px] leading-[17px] font-bold",
                            rightIcon: "/right-arrow.svg",
                            handleClick: ()=>setIsOpen(true)
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_CarDetails, {
                isOpen: isOpen,
                closeModal: ()=>setIsOpen(false),
                car: car
            })
        ]
    });
};
/* harmony default export */ const components_CarCard = (CarCard);


/***/ }),

/***/ 1897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Button = ({ isDisabled, btnType, containerStyles, textStyles, title, rightIcon, handleClick })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        disabled: isDisabled,
        type: btnType || "button",
        className: `custom-btn ${containerStyles}`,
        onClick: handleClick,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `flex-1 ${textStyles}`,
                children: title
            }),
            rightIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative w-6 h-6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: rightIcon,
                    alt: "arrow_left",
                    fill: true,
                    className: "object-contain"
                })
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 5608:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CustomFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6818);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6235);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1806);
/* __next_internal_client_entry_do_not_use__ default auto */ 





function CustomFilter({ title, options }) {
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(options[0]); // State for storing the selected option
    // update the URL search parameters and navigate to the new URL
    const handleUpdateParams = (e)=>{
        const newPathName = (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .updateSearchParams */ .aM)(title, e.value.toLowerCase());
        router.push(newPathName);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-fit",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Listbox */ .R, {
            value: selected,
            onChange: (e)=>{
                setSelected(e); // Update the selected option in state
                handleUpdateParams(e); // Update the URL search parameters and navigate to the new URL
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative w-fit z-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Listbox */ .R.Button, {
                        className: "custom-filter__btn",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "block truncate",
                                children: selected.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/chevron-up-down.svg",
                                width: 20,
                                height: 20,
                                className: "ml-4 object-contain",
                                alt: "chevron_up-down"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_6__/* .Transition */ .u, {
                        as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                        leave: "transition ease-in duration-100",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Listbox */ .R.Options, {
                            className: "custom-filter__options",
                            children: options.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Listbox */ .R.Option, {
                                    className: ({ active })=>`relative cursor-default select-none py-2 px-4 ${active ? "bg-primary-blue text-white" : "text-gray-900"}`,
                                    value: option,
                                    children: ({ selected })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: `block truncate ${selected ? "font-medium" : "font-normal"}`,
                                                children: option.title
                                            })
                                        })
                                }, option.title))
                        })
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 2259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9228);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Hero = ()=>{
    const handleScroll = ()=>{
        const nextSection = document.getElementById("discover");
        if (nextSection) {
            nextSection.scrollIntoView({
                behavior: "smooth"
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "hero",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 pt-36 padding-x",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "hero__title",
                        children: "Find, book, rent a car—quick and super easy!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "hero__subtitle",
                        children: "Streamline your car rental experience with our effortless booking process."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .CustomButton */ .op, {
                        title: "Explore Cars",
                        containerStyles: "bg-primary-blue text-white rounded-full mt-10",
                        handleClick: handleScroll
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "hero__image-container",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hero__image",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            src: "/hero.png",
                            alt: "hero",
                            fill: true,
                            className: "object-contain"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hero__image-overlay"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 4620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Searchbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/combobox/combobox.js + 1 modules
var combobox = __webpack_require__(3817);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7136);
;// CONCATENATED MODULE: ./components/SearchManufacturer.tsx





const SearchManufacturer = ({ manufacturer, setManuFacturer })=>{
    const [query, setQuery] = (0,react_.useState)("");
    const filteredManufacturers = query === "" ? constants/* manufacturers */.ui : constants/* manufacturers */.ui.filter((item)=>item.toLowerCase().replace(/\s+/g, "").includes(query.toLowerCase().replace(/\s+/g, "")));
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "search-manufacturer",
        children: /*#__PURE__*/ jsx_runtime_.jsx(combobox/* Combobox */.h, {
            value: manufacturer,
            onChange: setManuFacturer,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(combobox/* Combobox */.h.Button, {
                        className: "absolute top-[14px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/car-logo.svg",
                            width: 20,
                            height: 20,
                            className: "ml-4",
                            alt: "car logo"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(combobox/* Combobox */.h.Input, {
                        className: "search-manufacturer__input",
                        displayValue: (item)=>item,
                        onChange: (event)=>setQuery(event.target.value),
                        placeholder: "Volkswagen..."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
                        as: react_.Fragment,
                        leave: "transition ease-in duration-100",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0",
                        afterLeave: ()=>setQuery(""),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(combobox/* Combobox */.h.Options, {
                            className: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm",
                            static: true,
                            children: filteredManufacturers.length === 0 && query !== "" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(combobox/* Combobox */.h.Option, {
                                value: query,
                                className: "search-manufacturer__option",
                                children: [
                                    'Create "',
                                    query,
                                    '"'
                                ]
                            }) : filteredManufacturers.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(combobox/* Combobox */.h.Option, {
                                    className: ({ active })=>`relative search-manufacturer__option ${active ? "bg-primary-blue text-white" : "text-gray-900"}`,
                                    value: item,
                                    children: ({ selected, active })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: `block truncate ${selected ? "font-medium" : "font-normal"}`,
                                                    children: item
                                                }),
                                                selected ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: `absolute inset-y-0 left-0 flex items-center pl-3 ${active ? "text-white" : "text-pribg-primary-purple"}`
                                                }) : null
                                            ]
                                        })
                                }, item))
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_SearchManufacturer = (SearchManufacturer);

;// CONCATENATED MODULE: ./components/Searchbar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const SearchButton = ({ otherClasses })=>/*#__PURE__*/ jsx_runtime_.jsx("button", {
        type: "submit",
        className: `-ml-3 z-10 ${otherClasses}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: "/magnifying-glass.svg",
            alt: "magnifying glass",
            width: 40,
            height: 40,
            className: "object-contain"
        })
    });
const SearchBar = ()=>{
    const [manufacturer, setManuFacturer] = (0,react_.useState)("");
    const [model, setModel] = (0,react_.useState)("");
    const router = (0,navigation.useRouter)();
    const handleSearch = (e)=>{
        e.preventDefault();
        if (manufacturer.trim() === "" && model.trim() === "") {
            return alert("Please provide some input");
        }
        updateSearchParams(model.toLowerCase(), manufacturer.toLowerCase());
    };
    const updateSearchParams = (model, manufacturer)=>{
        // Create a new URLSearchParams object using the current URL search parameters
        const searchParams = new URLSearchParams(window.location.search);
        // Update or delete the 'model' search parameter based on the 'model' value
        if (model) {
            searchParams.set("model", model);
        } else {
            searchParams.delete("model");
        }
        // Update or delete the 'manufacturer' search parameter based on the 'manufacturer' value
        if (manufacturer) {
            searchParams.set("manufacturer", manufacturer);
        } else {
            searchParams.delete("manufacturer");
        }
        // Generate the new pathname with the updated search parameters
        const newPathname = `${window.location.pathname}?${searchParams.toString()}`;
        router.push(newPathname);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "searchbar",
        onSubmit: handleSearch,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "searchbar__item",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_SearchManufacturer, {
                        manufacturer: manufacturer,
                        setManuFacturer: setManuFacturer
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SearchButton, {
                        otherClasses: "sm:hidden"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "searchbar__item",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/model-icon.png",
                        width: 25,
                        height: 25,
                        className: "absolute w-[20px] h-[20px] ml-4",
                        alt: "car model"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        name: "model",
                        value: model,
                        onChange: (e)=>setModel(e.target.value),
                        placeholder: "Tiguan...",
                        className: "searchbar__input"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SearchButton, {
                        otherClasses: "sm:hidden"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SearchButton, {
                otherClasses: "max-sm:hidden"
            })
        ]
    });
};
/* harmony default export */ const Searchbar = (SearchBar);


/***/ }),

/***/ 8977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1806);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9228);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const ShowMore = ({ pageNumber, isNext })=>{
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const handleNavigation = ()=>{
        // Calculate the new limit based on the page number and navigation type
        const newLimit = (pageNumber + 1) * 10;
        // Update the "limit" search parameter in the URL with the new value
        const newPathname = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .updateSearchParams */ .aM)("limit", `${newLimit}`);
        router.push(newPathname);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full flex-center gap-5 mt-10",
        children: !isNext && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .CustomButton */ .op, {
            btnType: "button",
            title: "Show More",
            containerStyles: "bg-primary-blue rounded-full text-white",
            handleClick: handleNavigation
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShowMore);


/***/ }),

/***/ 9228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  op: () => (/* reexport */ components_CustomButton["default"])
});

// UNUSED EXPORTS: CarCard, CustomFilter, Footer, Hero, NavBar, SearchBar, ShowMore

// EXTERNAL MODULE: ./components/CarCard.tsx + 1 modules
var CarCard = __webpack_require__(605);
// EXTERNAL MODULE: ./components/CustomButton.tsx
var components_CustomButton = __webpack_require__(1897);
// EXTERNAL MODULE: ./components/CustomFilter.tsx
var CustomFilter = __webpack_require__(5608);
// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7136);
;// CONCATENATED MODULE: ./components/Footer.tsx




const Footer = ()=>/*#__PURE__*/ _jsxs("footer", {
        className: "flex flex-col text-black-100  mt-5 border-t border-gray-100",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "flex max-md:flex-col flex-wrap justify-between gap-5 sm:px-16 px-6 py-10",
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-col justify-start items-start gap-6",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: "/logo.svg",
                                alt: "logo",
                                width: 118,
                                height: 18,
                                className: "object-contain"
                            }),
                            /*#__PURE__*/ _jsxs("p", {
                                className: "text-base text-gray-700",
                                children: [
                                    "Carhub 2023 ",
                                    /*#__PURE__*/ _jsx("br", {}),
                                    "All Rights Reserved \xa9"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "footer__links",
                        children: footerLinks.map((item)=>/*#__PURE__*/ _jsxs("div", {
                                className: "footer__link",
                                children: [
                                    /*#__PURE__*/ _jsx("h3", {
                                        className: "font-bold",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "flex flex-col gap-5",
                                        children: item.links.map((link)=>/*#__PURE__*/ _jsx(Link, {
                                                href: link.url,
                                                className: "text-gray-500",
                                                children: link.title
                                            }, link.title))
                                    })
                                ]
                            }, item.title))
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "flex justify-between items-center flex-wrap mt-10 border-t border-gray-100 sm:px-16 px-6 py-10",
                children: [
                    /*#__PURE__*/ _jsx("p", {
                        children: "@2023 CarHub. All rights reserved"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "footer__copyrights-link",
                        children: [
                            /*#__PURE__*/ _jsx(Link, {
                                href: "/",
                                className: "text-gray-500",
                                children: "Privacy & Policy"
                            }),
                            /*#__PURE__*/ _jsx(Link, {
                                href: "/",
                                className: "text-gray-500",
                                children: "Terms & Condition"
                            })
                        ]
                    })
                ]
            })
        ]
    });
/* harmony default export */ const components_Footer = ((/* unused pure expression or super */ null && (Footer)));

;// CONCATENATED MODULE: ./components/Navbar.tsx




const NavBar = ()=>/*#__PURE__*/ _jsx("header", {
        className: "w-full  absolute z-10",
        children: /*#__PURE__*/ _jsxs("nav", {
            className: "max-w-[1440px] mx-auto flex justify-between items-center sm:px-16 px-6 py-4 bg-transparent",
            children: [
                /*#__PURE__*/ _jsx(Link, {
                    href: "/",
                    className: "flex justify-center items-center",
                    children: /*#__PURE__*/ _jsx(Image, {
                        src: "/logo.svg",
                        alt: "logo",
                        width: 118,
                        height: 18,
                        className: "object-contain"
                    })
                }),
                /*#__PURE__*/ _jsx(CustomButton, {
                    title: "Sign in",
                    btnType: "button",
                    containerStyles: "text-primary-blue rounded-full bg-white min-w-[130px]"
                })
            ]
        })
    });
/* harmony default export */ const Navbar = ((/* unused pure expression or super */ null && (NavBar)));

// EXTERNAL MODULE: ./components/ShowMore.tsx
var ShowMore = __webpack_require__(8977);
// EXTERNAL MODULE: ./components/Searchbar.tsx + 1 modules
var Searchbar = __webpack_require__(4620);
// EXTERNAL MODULE: ./components/Hero.tsx
var Hero = __webpack_require__(2259);
;// CONCATENATED MODULE: ./components/index.ts











/***/ }),

/***/ 7136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ui: () => (/* binding */ manufacturers)
/* harmony export */ });
/* unused harmony exports yearsOfProduction, fuels, footerLinks */
const manufacturers = [
    "Acura",
    "Alfa Romeo",
    "Aston Martin",
    "Audi",
    "Bentley",
    "BMW",
    "Buick",
    "Cadillac",
    "Chevrolet",
    "Chrysler",
    "Citroen",
    "Dodge",
    "Ferrari",
    "Fiat",
    "Ford",
    "GMC",
    "Honda",
    "Hyundai",
    "Infiniti",
    "Jaguar",
    "Jeep",
    "Kia",
    "Lamborghini",
    "Land Rover",
    "Lexus",
    "Lincoln",
    "Maserati",
    "Mazda",
    "McLaren",
    "Mercedes-Benz",
    "MINI",
    "Mitsubishi",
    "Nissan",
    "Porsche",
    "Ram",
    "Rolls-Royce",
    "Subaru",
    "Tesla",
    "Toyota",
    "Volkswagen",
    "Volvo"
];
const yearsOfProduction = [
    {
        title: "Year",
        value: ""
    },
    {
        title: "2015",
        value: "2015"
    },
    {
        title: "2016",
        value: "2016"
    },
    {
        title: "2017",
        value: "2017"
    },
    {
        title: "2018",
        value: "2018"
    },
    {
        title: "2019",
        value: "2019"
    },
    {
        title: "2020",
        value: "2020"
    },
    {
        title: "2021",
        value: "2021"
    },
    {
        title: "2022",
        value: "2022"
    },
    {
        title: "2023",
        value: "2023"
    }
];
const fuels = [
    {
        title: "Fuel",
        value: ""
    },
    {
        title: "Gas",
        value: "Gas"
    },
    {
        title: "Electricity",
        value: "Electricity"
    }
];
const footerLinks = [
    {
        title: "About",
        links: [
            {
                title: "How it works",
                url: "/"
            },
            {
                title: "Featured",
                url: "/"
            },
            {
                title: "Partnership",
                url: "/"
            },
            {
                title: "Bussiness Relation",
                url: "/"
            }
        ]
    },
    {
        title: "Company",
        links: [
            {
                title: "Events",
                url: "/"
            },
            {
                title: "Blog",
                url: "/"
            },
            {
                title: "Podcast",
                url: "/"
            },
            {
                title: "Invite a friend",
                url: "/"
            }
        ]
    },
    {
        title: "Socials",
        links: [
            {
                title: "Discord",
                url: "/"
            },
            {
                title: "Instagram",
                url: "/"
            },
            {
                title: "Twitter",
                url: "/"
            },
            {
                title: "Facebook",
                url: "/"
            }
        ]
    }
];


/***/ }),

/***/ 1806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Q_: () => (/* binding */ calculateCarRent),
/* harmony export */   aM: () => (/* binding */ updateSearchParams),
/* harmony export */   tx: () => (/* binding */ generateCarImageUrl)
/* harmony export */ });
/* unused harmony exports deleteSearchParams, fetchCars */
const calculateCarRent = (city_mpg, year)=>{
    const basePricePerDay = 50; // Base rental price per day in dollars
    const mileageFactor = 0.1; // Additional rate per mile driven
    const ageFactor = 0.05; // Additional rate per year of vehicle age
    // Calculate additional rate based on mileage and age
    const mileageRate = city_mpg * mileageFactor;
    const ageRate = (new Date().getFullYear() - year) * ageFactor;
    // Calculate total rental rate per day
    const rentalRatePerDay = basePricePerDay + mileageRate + ageRate;
    return rentalRatePerDay.toFixed(0);
};
const updateSearchParams = (type, value)=>{
    // Get the current URL search params
    const searchParams = new URLSearchParams(window.location.search);
    // Set the specified search parameter to the given value
    searchParams.set(type, value);
    // Set the specified search parameter to the given value
    const newPathname = `${window.location.pathname}?${searchParams.toString()}`;
    return newPathname;
};
const deleteSearchParams = (type)=>{
    // Set the specified search parameter to the given value
    const newSearchParams = new URLSearchParams(window.location.search);
    // Delete the specified search parameter
    newSearchParams.delete(type.toLocaleLowerCase());
    // Construct the updated URL pathname with the deleted search parameter
    const newPathname = `${window.location.pathname}?${newSearchParams.toString()}`;
    return newPathname;
};
async function fetchCars(filters) {
    const { manufacturer, year, model, limit, fuel } = filters;
    // Set the required headers for the API request
    // headers: {
    //   'X-RapidAPI-Key': 'b5d3348d90msh8b1ca21a04f33a3p115bb7jsn2f7dbd839b42',
    //   'X-RapidAPI-Host': 'cars-by-api-ninjas.p.rapidapi.com'
    // }
    const headers = {
        "X-RapidAPI-Key": "b5d3348d90msh8b1ca21a04f33a3p115bb7jsn2f7dbd839b42" || 0,
        "X-RapidAPI-Host": "cars-by-api-ninjas.p.rapidapi.com"
    };
    // Set the required headers for the API request
    const response = await fetch(`https://cars-by-api-ninjas.p.rapidapi.com/v1/cars?make=${manufacturer}&year=${year}&model=${model}&limit=${limit}&fuel_type=${fuel}`, {
        headers: headers
    });
    // Parse the response as JSON
    const result = await response.json();
    return result;
}
const generateCarImageUrl = (car, angle)=>{
    const url = new URL("https://cdn.imagin.studio/getimage");
    const { make, model, year } = car;
    url.searchParams.append("customer", "hrjavascript-mastery" || 0);
    url.searchParams.append("make", make);
    url.searchParams.append("modelFamily", model.split(" ")[0]);
    url.searchParams.append("zoomType", "fullscreen");
    url.searchParams.append("modelYear", `${year}`);
    // url.searchParams.append('zoomLevel', zoomLevel);
    url.searchParams.append("angle", `${angle}`);
    return `${url}`;
};


/***/ }),

/***/ 729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2817);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3807);



const metadata = {
    title: "Car Hub",
    description: "Discover world's best car showcase application"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
            className: "relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .NavBar */ .l2, {}),
                children,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Footer */ .$_, {})
            ]
        })
    });
}


/***/ }),

/***/ 7651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
;// CONCATENATED MODULE: ./utils/index.ts
const calculateCarRent = (city_mpg, year)=>{
    const basePricePerDay = 50; // Base rental price per day in dollars
    const mileageFactor = 0.1; // Additional rate per mile driven
    const ageFactor = 0.05; // Additional rate per year of vehicle age
    // Calculate additional rate based on mileage and age
    const mileageRate = city_mpg * mileageFactor;
    const ageRate = (new Date().getFullYear() - year) * ageFactor;
    // Calculate total rental rate per day
    const rentalRatePerDay = basePricePerDay + mileageRate + ageRate;
    return rentalRatePerDay.toFixed(0);
};
const updateSearchParams = (type, value)=>{
    // Get the current URL search params
    const searchParams = new URLSearchParams(window.location.search);
    // Set the specified search parameter to the given value
    searchParams.set(type, value);
    // Set the specified search parameter to the given value
    const newPathname = `${window.location.pathname}?${searchParams.toString()}`;
    return newPathname;
};
const deleteSearchParams = (type)=>{
    // Set the specified search parameter to the given value
    const newSearchParams = new URLSearchParams(window.location.search);
    // Delete the specified search parameter
    newSearchParams.delete(type.toLocaleLowerCase());
    // Construct the updated URL pathname with the deleted search parameter
    const newPathname = `${window.location.pathname}?${newSearchParams.toString()}`;
    return newPathname;
};
async function fetchCars(filters) {
    const { manufacturer, year, model, limit, fuel } = filters;
    // Set the required headers for the API request
    // headers: {
    //   'X-RapidAPI-Key': 'b5d3348d90msh8b1ca21a04f33a3p115bb7jsn2f7dbd839b42',
    //   'X-RapidAPI-Host': 'cars-by-api-ninjas.p.rapidapi.com'
    // }
    const headers = {
        "X-RapidAPI-Key": "b5d3348d90msh8b1ca21a04f33a3p115bb7jsn2f7dbd839b42" || 0,
        "X-RapidAPI-Host": "cars-by-api-ninjas.p.rapidapi.com"
    };
    // Set the required headers for the API request
    const response = await fetch(`https://cars-by-api-ninjas.p.rapidapi.com/v1/cars?make=${manufacturer}&year=${year}&model=${model}&limit=${limit}&fuel_type=${fuel}`, {
        headers: headers
    });
    // Parse the response as JSON
    const result = await response.json();
    return result;
}
const generateCarImageUrl = (car, angle)=>{
    const url = new URL("https://cdn.imagin.studio/getimage");
    const { make, model, year } = car;
    url.searchParams.append("customer", "hrjavascript-mastery" || 0);
    url.searchParams.append("make", make);
    url.searchParams.append("modelFamily", model.split(" ")[0]);
    url.searchParams.append("zoomType", "fullscreen");
    url.searchParams.append("modelYear", `${year}`);
    // url.searchParams.append('zoomLevel', zoomLevel);
    url.searchParams.append("angle", `${angle}`);
    return `${url}`;
};

// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(6406);
// EXTERNAL MODULE: ./components/index.ts + 8 modules
var components = __webpack_require__(3807);
;// CONCATENATED MODULE: ./app/page.tsx




async function Home({ searchParams }) {
    const allCars = await fetchCars({
        manufacturer: searchParams.manufacturer || "",
        year: searchParams.year || 2022,
        fuel: searchParams.fuel || "",
        limit: searchParams.limit || 10,
        model: searchParams.model || ""
    });
    const isDataEmpty = !Array.isArray(allCars) || allCars.length < 1 || !allCars;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Hero */.VM, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-12 padding-x padding-y max-width",
                id: "discover",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "home__text-container",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl font-extrabold",
                                children: "Car Catalogue"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Explore out cars you might like"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "home__filters",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components/* SearchBar */.E1, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "home__filter-container",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(components/* CustomFilter */.Xy, {
                                        title: "fuel",
                                        options: constants/* fuels */.nQ
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(components/* CustomFilter */.Xy, {
                                        title: "year",
                                        options: constants/* yearsOfProduction */.uY
                                    })
                                ]
                            })
                        ]
                    }),
                    !isDataEmpty ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "home__cars-wrapper",
                                children: allCars?.map((car)=>/*#__PURE__*/ jsx_runtime_.jsx(components/* CarCard */._h, {
                                        car: car
                                    }))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components/* ShowMore */.gm, {
                                pageNumber: (searchParams.limit || 10) / 10,
                                isNext: (searchParams.limit || 10) > allCars.length
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "home__error-container",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-black text-xl font-bold",
                                children: "Oops, no results"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: allCars?.message
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3807:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _h: () => (/* reexport */ CarCard),
  Xy: () => (/* reexport */ CustomFilter),
  $_: () => (/* reexport */ components_Footer),
  VM: () => (/* reexport */ Hero),
  l2: () => (/* reexport */ Navbar),
  E1: () => (/* reexport */ Searchbar),
  gm: () => (/* reexport */ ShowMore)
});

// UNUSED EXPORTS: CustomButton

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./components/CarCard.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\CarCard.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const CarCard = (__default__);
;// CONCATENATED MODULE: ./components/CustomButton.tsx

const CustomButton_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\CustomButton.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: CustomButton_esModule, $$typeof: CustomButton_$$typeof } = CustomButton_proxy;
const CustomButton_default_ = CustomButton_proxy.default;


/* harmony default export */ const CustomButton = (CustomButton_default_);
;// CONCATENATED MODULE: ./components/CustomFilter.tsx

const CustomFilter_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\CustomFilter.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: CustomFilter_esModule, $$typeof: CustomFilter_$$typeof } = CustomFilter_proxy;
const CustomFilter_default_ = CustomFilter_proxy.default;


/* harmony default export */ const CustomFilter = (CustomFilter_default_);
// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(6406);
;// CONCATENATED MODULE: ./components/Footer.tsx




const Footer = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "flex flex-col text-black-100  mt-5 border-t border-gray-100",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex max-md:flex-col flex-wrap justify-between gap-5 sm:px-16 px-6 py-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-start items-start gap-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/logo.svg",
                                alt: "logo",
                                width: 118,
                                height: 18,
                                className: "object-contain"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-base text-gray-700",
                                children: [
                                    "Carhub 2023 ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "All Rights Reserved \xa9"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer__links",
                        children: constants/* footerLinks */.dk.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "footer__link",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "font-bold",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex flex-col gap-5",
                                        children: item.links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: link.url,
                                                className: "text-gray-500",
                                                children: link.title
                                            }, link.title))
                                    })
                                ]
                            }, item.title))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-center flex-wrap mt-10 border-t border-gray-100 sm:px-16 px-6 py-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "@2023 CarHub. All rights reserved"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "footer__copyrights-link",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                className: "text-gray-500",
                                children: "Privacy & Policy"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                className: "text-gray-500",
                                children: "Terms & Condition"
                            })
                        ]
                    })
                ]
            })
        ]
    });
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./components/Navbar.tsx




const NavBar = ()=>/*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "w-full  absolute z-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
            className: "max-w-[1440px] mx-auto flex justify-between items-center sm:px-16 px-6 py-4 bg-transparent",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    className: "flex justify-center items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/logo.svg",
                        alt: "logo",
                        width: 118,
                        height: 18,
                        className: "object-contain"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(CustomButton, {
                    title: "Sign in",
                    btnType: "button",
                    containerStyles: "text-primary-blue rounded-full bg-white min-w-[130px]"
                })
            ]
        })
    });
/* harmony default export */ const Navbar = (NavBar);

;// CONCATENATED MODULE: ./components/ShowMore.tsx

const ShowMore_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\ShowMore.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ShowMore_esModule, $$typeof: ShowMore_$$typeof } = ShowMore_proxy;
const ShowMore_default_ = ShowMore_proxy.default;


/* harmony default export */ const ShowMore = (ShowMore_default_);
;// CONCATENATED MODULE: ./components/Searchbar.tsx

const Searchbar_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\Searchbar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Searchbar_esModule, $$typeof: Searchbar_$$typeof } = Searchbar_proxy;
const Searchbar_default_ = Searchbar_proxy.default;


/* harmony default export */ const Searchbar = (Searchbar_default_);
;// CONCATENATED MODULE: ./components/Hero.tsx

const Hero_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ProKa\OneDrive\Desktop\Application\Nextjs Applications\nextcarrental\components\Hero.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Hero_esModule, $$typeof: Hero_$$typeof } = Hero_proxy;
const Hero_default_ = Hero_proxy.default;


/* harmony default export */ const Hero = (Hero_default_);
;// CONCATENATED MODULE: ./components/index.ts











/***/ }),

/***/ 6406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dk: () => (/* binding */ footerLinks),
/* harmony export */   nQ: () => (/* binding */ fuels),
/* harmony export */   uY: () => (/* binding */ yearsOfProduction)
/* harmony export */ });
/* unused harmony export manufacturers */
const manufacturers = (/* unused pure expression or super */ null && ([
    "Acura",
    "Alfa Romeo",
    "Aston Martin",
    "Audi",
    "Bentley",
    "BMW",
    "Buick",
    "Cadillac",
    "Chevrolet",
    "Chrysler",
    "Citroen",
    "Dodge",
    "Ferrari",
    "Fiat",
    "Ford",
    "GMC",
    "Honda",
    "Hyundai",
    "Infiniti",
    "Jaguar",
    "Jeep",
    "Kia",
    "Lamborghini",
    "Land Rover",
    "Lexus",
    "Lincoln",
    "Maserati",
    "Mazda",
    "McLaren",
    "Mercedes-Benz",
    "MINI",
    "Mitsubishi",
    "Nissan",
    "Porsche",
    "Ram",
    "Rolls-Royce",
    "Subaru",
    "Tesla",
    "Toyota",
    "Volkswagen",
    "Volvo"
]));
const yearsOfProduction = [
    {
        title: "Year",
        value: ""
    },
    {
        title: "2015",
        value: "2015"
    },
    {
        title: "2016",
        value: "2016"
    },
    {
        title: "2017",
        value: "2017"
    },
    {
        title: "2018",
        value: "2018"
    },
    {
        title: "2019",
        value: "2019"
    },
    {
        title: "2020",
        value: "2020"
    },
    {
        title: "2021",
        value: "2021"
    },
    {
        title: "2022",
        value: "2022"
    },
    {
        title: "2023",
        value: "2023"
    }
];
const fuels = [
    {
        title: "Fuel",
        value: ""
    },
    {
        title: "Gas",
        value: "Gas"
    },
    {
        title: "Electricity",
        value: "Electricity"
    }
];
const footerLinks = [
    {
        title: "About",
        links: [
            {
                title: "How it works",
                url: "/"
            },
            {
                title: "Featured",
                url: "/"
            },
            {
                title: "Partnership",
                url: "/"
            },
            {
                title: "Bussiness Relation",
                url: "/"
            }
        ]
    },
    {
        title: "Company",
        links: [
            {
                title: "Events",
                url: "/"
            },
            {
                title: "Blog",
                url: "/"
            },
            {
                title: "Podcast",
                url: "/"
            },
            {
                title: "Invite a friend",
                url: "/"
            }
        ]
    },
    {
        title: "Socials",
        links: [
            {
                title: "Discord",
                url: "/"
            },
            {
                title: "Instagram",
                url: "/"
            },
            {
                title: "Twitter",
                url: "/"
            },
            {
                title: "Facebook",
                url: "/"
            }
        ]
    }
];


/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [381,572], () => (__webpack_exec__(3140)));
module.exports = __webpack_exports__;

})();